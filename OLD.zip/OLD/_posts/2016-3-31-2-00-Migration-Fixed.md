---
layout: post
title: The forums are fixed!
---

As of a few minutes ago, we have successfully fixed all of the problems that came about during the migration.  We can now have a focus on the main site!
