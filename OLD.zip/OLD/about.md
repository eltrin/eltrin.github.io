---
layout: page
title: About
---

We are a gaming company that's currently working on the prototype of our first ever game: [Project EGO](http://eltrin.com/Project%20EGO/).
